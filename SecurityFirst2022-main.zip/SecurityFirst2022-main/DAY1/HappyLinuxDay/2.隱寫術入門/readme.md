# 學習大綱|agenda 

- 1_認識 隱寫術 Steganography 
- 2_圖片隱寫術之1:基本入門技_使用linux 基本指令file|strings|grep
- 3_圖片隱寫術之2:圖片內嵌解答圖片的解題
  - 你必須會回答 檔案格式(file signature)
  - 會使用hex編輯器分析檔案
  - 會使用Linux的dd、binwalk指令解圖片隱寫術
- 4_圖片隱寫術之3:圖片的metadata    


# 建議作業
## 建議作業1:網路還有許多分析圖片中隱藏機密的各種技巧 ==> 請整理到你的github
- 高中職學生要申請加入台灣好厲駭,記得要提供你的github ==> 會加分

## 建議作業2:完成 隱寫術102 的 `writeups(解答報告)`

## 建議作業3:延伸研讀audio隱寫術 ==> 鼓勵大家上網找資料學習 再分享給同學
```
老師沒教的! 同學自己學習到的! 能清楚分享給同學的! 更加珍貴!
```
```
常用工具
Audacity  ==>https://zh.wikipedia.org/wiki/Audacity       
          ==>官方網址https://www.audacityteam.org/
          
Audacity是一款跨平台的音訊編輯軟體，用於錄音和編輯音訊，是自由、開放原始碼的軟體。
可在Mac OS X、Microsoft Windows、GNU/Linux和其它作業系統上運作

GoldWave ==> https://zh.wikipedia.org/wiki/GoldWave
          ==>官方網址 http://www.goldwave.com/
```
