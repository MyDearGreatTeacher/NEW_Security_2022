## 2_網路鑑識分析第一步_使用linux基本指令進行分析  
## Linux 常用指令之 strings

- 使用strings來檢視檔案內所有可視字元


## 範例練習1:Network101|CSAW Quals CTF 2013: Networking 10
- strings 檔案名稱  ==> 就可以看到答案


## 範例練習2:Network101|BITSCTF 2017 : woodstock-1-10
- strings 檔案名稱
- strings 檔案名稱 | grep BITSCTF
  - 使用grep找strings後包含BITSCTF的字串
  
 
