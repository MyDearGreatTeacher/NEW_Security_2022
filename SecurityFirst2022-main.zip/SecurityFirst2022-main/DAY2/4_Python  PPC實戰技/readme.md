# 使用python程式實戰`PPC(Professional Program Code)`

## 本課程使用 Ubuntu Linux 18.04 LTS(已安裝好pwntools)  [下載點](https://drive.google.com/file/d/1aP-qCFP6jKsGYXtKy9ahwZleQSENEi7C/view?usp=sharing)

## 課程內容
- 1_在Ubuntu linux開發Python程式
- 2_pwntools:CTF資安競賽最最著名的第三方模組
- 3_pwntools實戰入門技:使用pwntools解ppc
- 4_更多PPC(Professional Program Code)程式範例解題


 
