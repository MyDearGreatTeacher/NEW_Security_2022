# 使用python程式求解 古典密碼的破密
- 依時間規範講解底下題目,特別是強調處理邏輯與程式語法
- 1_使用Python求解變形caesar密碼 RC3 CTF 2016 : salad-100
- 2_School CTF 2015: affine-cipher-100(教)
- 3_AlexCTF: Fore1: Hit the core
